let nombreJugador = "";
let nivelesCompletados = {
  nivel1: false,
  nivel2: false,
  nivel3: false,
  nivel4: false
};

// Inicia el juego y solicita el nombre
function startGame() {
  nombreJugador = prompt("¿Cuál es tu nombre, Guardián del Código?");
  if (!nombreJugador) nombreJugador = "Anónimo";

  document.getElementById('intro').style.display = 'none';
  document.getElementById('contenido').style.display = 'block';

  alert("¡Comienza tu aventura, " + nombreJugador + "!");
}

// Misión Nivel 1
function verificarNivel1() {
  const codigo = document.getElementById("codigoNivel1").value.trim();
  const edad = 20;

  // Verifica que se use 'if' en minúscula como palabra completa
  const usaIfCorrecto = /\bif\b/.test(codigo);

  // Verifica que NO se use 'If' o 'IF' (mayúsculas)
  const usaIfIncorrecto = /\bIf\b|\bIF\b/.test(codigo);

  // Verifica que se use 'edad'
  const contieneEdad = /edad/.test(codigo);

  if (!usaIfCorrecto || usaIfIncorrecto || !contieneEdad) {
    alert("Tu código debe usar 'if' en minúsculas, no contener 'If' o 'IF', y debe usar la variable 'edad'.");
    return;
  }

  try {
    // Intenta ejecutar el código ingresado
    const funcion = new Function("edad", codigo + "\nreturn false;");
    const resultado = funcion(edad);

    if (resultado === true) {
      alert("¡Correcto! Usaste la sintaxis adecuada.");
      document.getElementById("medalla1").style.display = "block";
      nivelesCompletados.nivel1 = true;
      verificarGraduacion();
    } else {
      alert("El código se ejecutó, pero no retornó true como se esperaba.");
    }
  } catch (e) {
    alert("Tu código tiene errores de sintaxis. Revisa si escribiste bien todo.");
  }
}


// Misión Nivel 2
function verificarNivel2() {
  let direccion = prompt("Buenos días/ Buenas noches");
  if (direccion === "Buenos días") {
    alert("¡Tesoro encontrado!");
    document.getElementById("medalla2").style.display = "block";
    nivelesCompletados.nivel2 = true;
    verificarGraduacion();
  } else if (direccion === "Buenas noches") {
    alert("Caíste en una trampa.Vuelve a intentarlo.");
  } else {
    alert("Te perdiste.");
  }
}

// Misión Nivel 3
function verificarNivel3() {
  const codigo = document.getElementById("codigoNivel3").value.trim();
  const llueve = true;

  const contieneIf = /\bif\b/.test(codigo);
  const contieneLlueve = /llueve/.test(codigo);

  if (!contieneIf || !contieneLlueve) {
    alert("Tu código debe usar un 'if' y la variable 'llueve'.");
    return;
  }

  try {
    const funcion = new Function("llueve", codigo + "\nreturn '';"); // para evitar errores si no retorna nada
    const resultado = funcion(llueve);

    if (resultado === "Tomás el ómnibus") {
      alert("¡Correcto! Has elegido bien.");
      document.getElementById("medalla3").style.display = "block";
      nivelesCompletados.nivel3 = true;
      verificarGraduacion();
    } else {
      alert("El resultado no fue el esperado. ¿Estás tomando el ómnibus cuando llueve?");
    }
  } catch (e) {
    alert("Tu código tiene errores. Revisa la sintaxis.");
  }
}

// Misión Nivel 4

function verificarNivel4() {
  const codigo = document.getElementById("codigoUsuario").value.trim();
  const num = 8; // número de prueba, que sí es par

  // Validación de estructura
  const contieneIf = /if\s*\(.*\)/.test(codigo);
  const contieneModulo = /num\s*%\s*2/.test(codigo);

  if (!contieneIf || !contieneModulo) {
    alert("Tu código debe incluir una estructura 'if' y verificar si 'num % 2 === 0'.");
    return;
  }

  // Intentar ejecutar el código
  try {
    const funcionUsuario = new Function("num", codigo + "\nreturn false;");
    const resultado = funcionUsuario(num);

    if (resultado === true) {
      alert("¡Correcto! Has desbloqueado el portal.");
      document.getElementById("medalla4").style.display = "block";
      nivelesCompletados.nivel4 = true;
      verificarGraduacion();
    } else {
      alert("Tu código fue ejecutado pero no retorna true cuando num es par.");
    }
  } catch (e) {
    alert("Hay un error en tu código. Revisa la sintaxis.");
  }
}

// Verifica si se completaron los 4 niveles y muestra la graduación
function verificarGraduacion() {
  if (
    nivelesCompletados.nivel1 &&
    nivelesCompletados.nivel2 &&
    nivelesCompletados.nivel3 &&
    nivelesCompletados.nivel4 
  ) {
    document.getElementById("graduacion").style.display = "block";
    document.getElementById("nombre-jugador").textContent = nombreJugador;
    document.getElementById("nombre-en-certificado").textContent = nombreJugador;
    document.getElementById("certificado").style.display = "block";
  }
}

// Genera y descarga el certificado como imagen
function descargarCertificado() {
  const certificado = document.getElementById("certificado");
  html2canvas(certificado).then(canvas => {
    const enlace = document.createElement("a");
    enlace.href = canvas.toDataURL("image/png");
    enlace.download = `certificado-${nombreJugador}.png`;
    enlace.click();
  });
}

